# vue-html-to-paper
Vue mixin for paper printing html elements.

### Demo

https://mycurelabs.github.io/vue-html-to-paper/

### Documentation

https://randomcodetips.com/vue-html-to-paper/

Made with ❤️ by Jofferson Ramirez Tiquez
