export default {
  input: 'src/index.js',
  output: {
    file: 'build/vue-html-to-paper.js',
    name: 'VueHtmlToPaper',
    format: 'umd'
  }
};